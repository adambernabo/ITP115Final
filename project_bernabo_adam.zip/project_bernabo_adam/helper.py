# Adam Bernabo, bernabo@usc.edu
# ITP 115, Fall 2022
# Final Project
# helper.py
# Description:
# This file gets creates a list of all the of dictionaries that contain all the roller coasters in the
# 'roller_coasters.csv' file and their respective data. It also creates a list of all the parks in alphabetical order.
# in addition, it creates a dictionary for the coaster with the fastest speed and longest length. Also finds the park
# with the most coasters.

# Parameter: filenameStr is the name of the CSV file to read and has a default value of "roller_coasters.csv". Return
# value: This function creates a list of dictionaries containing the information about each roller coaster from the csv
# file.
def createCoastersFromFile(filenameStr = "roller_coasters.csv"):
    # list of dictionaries of roller coaster info
    coastersList = []
    # opens the csv file and uses the .readline() function to read the first line. Line is then stripped and split into
    # a list which becomes the data fields for the roller coaster dictionaries
    fin = open(filenameStr,"r")
    specs = fin.readline()
    keyList = specs.strip().split(",")
    # for the rest of the lines, they are stripped and made into a comma delineated list. An empty dictionary is created
    # which houses the roller coaster's data.
    for line in fin:
        line = line.strip().split(",")
        pairs = {}
        # a range-based loop then goes through the keyList. Branching is used to remove the 'status.' from the
        # operational status of the roller coaster.
        for i in range(len(keyList)):
            if keyList[i] == "status":
                line[i] = line[i].replace("status.","")
            # the key and definition is then added to the dictionary for each field and the corresponding data.
            pairs[keyList[i]] = line[i]
        # The dictionary for each roller coaster is then added to the list of dictionaries and that list is then
        # returned once it has every roller coaster.
        coastersList.append(pairs)
    return coastersList


# Parameter: the list of dictionaries containing the info about the coasters. Return value: a sorted list of all the
# amusement park names.
def getParksList(coastersList):
    # empty list of parks
    parksList = []
    # goes through each dictionary in the list. For each dictionary, finds the definition of the key 'park'. If the
    # definition (the name of the park) isn't already in the list of parks, the park is added to the list.
    for coaster in coastersList:
        if coaster["park"] not in parksList:
            parksList.append(coaster["park"])
    parksList.sort()
    return parksList


# Parameter: the list of dictionaries containing the info about the coasters. Return value: a dictionary containing the
# info of the fastest coaster.
def getFastestCoaster(coastersList):
    # declare the fastest speed as zero and fastestCoaster as an empty dictionary
    fastestSpeed = 0
    fastestCoaster = {}
    # loops through every coaster
    for coaster in coastersList:
        # makes sure the coaster has a valid speed before turning it into an integer
        if coaster["speed"].isdigit():
            speed = int(coaster["speed"])
            # if the max speed of the coaster is faster that the current fastest speed, that coaster's speed becomes the
            # fastest speed. That coaster's dictionary also becomes the dictionary of the fastest coaster.
            if speed > fastestSpeed:
                fastestSpeed = speed
                fastestCoaster = coastersList[coastersList.index(coaster)]
    # the dictionary for the fastest coaster is then returned
    return fastestCoaster


def getLongestCoaster(coastersList):
    # declare the longestLength as zero and longestCoaster as an empty dictionary
    longestLength = 0
    longestCoaster = {}
    # loops through every coaster
    for coaster in coastersList:
        # makes sure the coaster has a valid length before turning it into an integer
        if coaster["length"].isdigit():
            length = int(coaster["length"])
            # if the length of the coaster is longer that the current longest length, that coaster's length becomes the
            # longest length. That coaster's dictionary also becomes the dictionary of the longest coaster.
            if length > longestLength:
                longestLength = length
                longestCoaster = coastersList[coastersList.index(coaster)]
    # the dictionary for the longest coaster is then returned
    return longestCoaster


# Parameter: a list of dictionaries of all the roller coasters and their data. Return value: a string containing the
# name of the park with the most roller coasters. This function finds the park with the most coasters.
def getParkMostCoasters(coastersList):
    # mostCoasters holds the largest number of coasters. mostCoastersPark hold the string with the park with the most
    # coasters
    mostCoasters = 0
    mostCoastersPark = ""
    # uses the getParksList function to get a list of all the parks
    parksList = getParksList(coastersList)
    # for each park in the list, resets the amount of coasters back to 0
    for park in parksList:
        coasterCounter = 0
        # goes through each coaster. If the coaster's 'park' definition is equal to the current park, adds one to the
        # coaster counter
        for coaster in coastersList:
            if coaster["park"] == park:
                coasterCounter += 1
        # after checking every coaster, compares the amount of coaster whose park is the current park in the park for
        # loop. If the current park's amount of coasters is larger, makes that park the park with the most coasters and
        # makes coaster counter the current most coasters.
        if coasterCounter > mostCoasters:
            mostCoasters = coasterCounter
            mostCoastersPark = park
    # once every park has been checked, the park with the largest amount of coasters is returned.
    return mostCoastersPark


