# Adam Bernabo, bernabo@usc.edu
# ITP 115, Fall 2022
# Final Project
# user_interface.py
# Description:
# This file displays the menu of what the user can do and allows the user to input what they would like to do. It has
# functions that display the number of total coasters, the number of operating coasters, the info of specific coasters,
# the fastest and longest coaster, the park with the most coasters, all the parks, the coasters in a given park, and the
# coasters whose name contain a user-defined search term.

import helper


# Parameter: the dictionary containing the menu options and their descriptions. No return Value. This function displays
# the menu options and their descriptions to the user.
def displayMenu(menuDict):
    # an empty list that will hold the sorted keys
    sortedKeys = []
    # each key in menuDict is appended to the sortedKeys list using a for loop
    for key in menuDict:
        sortedKeys.append(key)
    # the loop is then sorted
    sortedKeys.sort()
    # each key is printed alphabetically using the sortedKey list. Then, an arrow and the corresponding definition is
    # printed using the menuDict
    print()
    for sortedKey in sortedKeys:
        print(sortedKey+" -> "+menuDict[sortedKey])


# Parameter: the dictionary containing the menu options and their descriptions. Return value: valid user input. This
# function takes input from the user and makes ure it is valid input.
def getUserChoice(menuDict):
    # dummy value used so that the while loop can be entered.
    userInput = "ham"
    # while loop makes the user giving input until what they have entered, once stripped and capitalized, is a key in
    # menuDict
    while userInput not in menuDict:
        userInput = input("Choice: ")
        userInput = userInput.strip().upper()
    # Once the user has entered a valid input, it is returned
    return userInput


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# the total amount of coasters on the list.
def displayNumCoasters(coastersList):
    # counter for the amount of coasters
    coasterCounter = 0
    # a for loop is used such that, for each coaster in the coastersList, the coasterCounter increases by 1
    for coaster in coastersList:
        coasterCounter += 1
    # the counter is then used to display the total number of coasters
    print("The total number of coasters is "+str(coasterCounter))


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# the total amount of operating coasters on the list.
def displayNumOperatingCoasters(coastersList):
    # counter
    numOperatingCoasters = 0
    # for loop goes through each coaster's dictionary
    for coaster in coastersList:
        # branching is used such that, if the definition of 'status' in 'operational', then the counter of operating
        # coasters increases by one
        if coaster["status"] == "operating":
            numOperatingCoasters += 1
    # the 'numOperatingCoasters' counter is then used to display the total number of operating coasters
    print("The total number of operating coasters is "+str(numOperatingCoasters))


# Parameter: A dictionary containing the info about a roller coaster. No return Value. This function displays the info
# about a roller coaster if the data exists.
def displayCoaster(coasterDict):
    # prints the name and park of the coaster using the coasterDict dictionary
    print(coasterDict["name"]+" ["+coasterDict["park"]+"]")
    # uses branching to show the roller coaster's stats only if they have valid data
    if coasterDict["speed"] != "":
        print("\tSpeed = "+coasterDict["speed"]+" mph")
    if coasterDict["height"] != "":
        print("\tHeight = "+coasterDict["height"]+" ft")
    if coasterDict["length"] != "":
        print("\tLength = "+coasterDict["length"]+" ft")
    if coasterDict["status"] != "":
        print("\tStatus is "+coasterDict["status"])


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# the info about the fastest coaster on the list using the list of coasters and the getFastestCoaster function from the
# helper file.
def displayFastestCoaster(coastersList):
    # the fastest coaster's dictionary is saved to the variable coasterDict. The displayCoaster function is then used
    # to display the information in coasterDict.
    coasterDict = helper.getFastestCoaster(coastersList)
    displayCoaster(coasterDict)


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# the info about the longest coaster on the list using the list of coasters and the getLongestCoaster function from the
# helper file.
def displayLongestCoaster(coastersList):
    # the fastest coaster's dictionary is saved to the variable coasterDict. The displayCoaster function is then used
    # to display the information in coasterDict.
    coasterDict = helper.getLongestCoaster(coastersList)
    displayCoaster(coasterDict)


# Parameter: the list of dictionaries for each coaster. No return value. Displays the coasters in the park with the most
# coasters and the name of the park as well as how many total coasters.
def displayParkMostCoasters(coastersList):
    # counter for the amount of coasters
    coasterCount = 0
    # uses the getParkMostCoasters function to find the park with the most coasters
    parkMostCoasters = helper.getParkMostCoasters(coastersList)
    # for each coaster, checks if the park is equal to parkMostCoasters
    for coaster in coastersList:
        # if so, the coaster is displayed using the displayCoaster function and the coasterCount increases by 1.
        if coaster["park"] == parkMostCoasters:
            displayCoaster(coaster)
            coasterCount += 1
    # after displaying all the coasters, uses the parkMostCoasters and coasterCount variables to tell the user the park
    # with the most coasters as well as how many total coasters are in that park.
    print(parkMostCoasters+" has "+str(coasterCount)+" coasters")


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# the all the amusement parks and how many total there are using the coaster list and the getParksList function from the
# helper file.
def displayAllParks(coastersList):
    # counter for the number of parks
    numParks = 0
    # uses the getParksList function to save the sorted list of parks to the parksList variable
    parksList = helper.getParksList(coastersList)
    print("Amusement parks in alphabetical order:")
    # for each park in the list, the name of the park is displayed and the numParks counter increases by 1.
    for park in parksList:
        numParks += 1
        print(park)
    # The total number of parks is then shown using the numParks counter.
    print("There are "+str(numParks)+" unique parks.")


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# all the coasters in a certain park based off of the user's input using the displayCoaster. Lets the user now how many
# coasters on the list are in that specific park.
def displayCoastersInPark(coastersList):
    # counter of the amount of coasters in the user-specified park
    coastersInPark = 0
    # user input is taken, stripped, and titled
    userInput = input("Enter a park: ")
    userInput = userInput.strip().title()
    # loops through each coaster
    for coaster in coastersList:
        # if the user's input is found within the park name of the coaster, the coaster is displayed using the
        # displayCoaster function and the coastersInPark counter increases by one.
        if userInput in coaster["park"]:
            displayCoaster(coaster)
            coastersInPark += 1
    # branching is used such that if the user's input was not found in any coaster, they are told there are no coasters
    # in that bark. If there is more than 0 coasters in the park, the user is told how many coasters are in their
    # inputted park.
    if coastersInPark > 0:
        print(userInput+" has "+str(coastersInPark)+" coasters")
    else:
        print("No coasters in "+userInput)


# Parameter: the list of dictionaries containing the info about the coasters. No return Value. This function displays
# all the coasters whose name contain a user-given key word/phrase. Uses the list of coasters and displayCoasters
# function to show the info about the coasters that fit the given criteria as well as how many coasters that includes.
def findCoasters(coastersList):
    # counter of the amount of coasters that have the user's input in their name
    coasterCounter = 0
    # takes user's input and strips and titles it
    userInput = input("Enter a search phrase: ")
    userInput = userInput.strip().title()
    # loops through each coaster in the list
    for coaster in coastersList:
        # if the user's input is a part of any one the names of the coaster, that coaster's data is displayed using the
        # displayCoaster function and the coasterCounter increases by 1.
        if userInput in coaster["name"]:
            displayCoaster(coaster)
            coasterCounter += 1
    # branching is then used to tell the user how many coasters fitted their search term if the coaster counter was
    # greater than zero. if coasterCounter is still equal to 0, the user is told there were no coasters whose name
    # contained their search term.
    if coasterCounter > 0:
        print("Found "+str(coasterCounter)+" coasters that contain \'"+userInput+"\'")
    else:
        print("No coasters contain \'"+userInput+"\'")
