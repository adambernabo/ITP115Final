# Adam Bernabo, bernabo@usc.edu
# ITP 115, Fall 2022
# Final Project
# main_bernabo_adam.py
# Description:
# Allows the user to see different data from the 'roller_coasters.csv' file using the functions defined in the helper
# and user_interface files based on the user's input based on the menu of options.

import helper
import user_interface


# No parameter. Returns a dictionary containing menu options and their descriptions.
def getMenuDict():
    # returns a dictionary with the different menu choices and their descriptions
    menuDict = {"A":"Number of coasters","B":"Number of operating coasters","C":"Fastest coaster","D":"Amusement parks"
                 ,"E":"Coasters in a park","F":"Find coasters","G":"Longest coaster","H":"Park with most coasters","Q":
                    "Quit"}
    return menuDict


# No parameters or return values. Allows the user to see different data from the 'roller_coasters.csv' file using the
# functions defined in the helper and user_interface files based on the user's input based on the menu of options.
def main():
    print("Roller Coasters")
    # gets a list of dictionaries with all the information about each roller coaster using the helper file
    coastersList = helper.createCoastersFromFile()
    # gets the dictionary of menu options and descriptions from the above function
    menuDict = getMenuDict()
    userChoice = ""
    # uses a while loop to allow the user to see the menu and make valid input using the functions from the
    # user_interface fle while the user's input isn't equal to that which quites the loop
    while not userChoice == "Q" or userChoice == "q":
        user_interface.displayMenu(menuDict)
        userChoice = user_interface.getUserChoice(menuDict)
        # branching is used so that the appropriate function runs based on the user's input
        if userChoice == "A":
            user_interface.displayNumCoasters(coastersList)
        elif userChoice == "B":
            user_interface.displayNumOperatingCoasters(coastersList)
        elif userChoice == "C":
            user_interface.displayFastestCoaster(coastersList)
        elif userChoice == "D":
            user_interface.displayAllParks(coastersList)
        elif userChoice == "E":
            user_interface.displayCoastersInPark(coastersList)
        elif userChoice == "F":
            user_interface.findCoasters(coastersList)
        elif userChoice == "G":
            user_interface.displayLongestCoaster(coastersList)
        elif userChoice == "H":
            user_interface.displayParkMostCoasters(coastersList)


main()

